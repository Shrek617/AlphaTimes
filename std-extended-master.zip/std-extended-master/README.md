# std-extended

Some very basic but very useful C++ components, based on the design of the std.
