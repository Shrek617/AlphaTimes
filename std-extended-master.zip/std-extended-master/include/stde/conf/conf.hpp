#ifndef STDE_CONF_CONF_HPP_
#define STDE_CONF_CONF_HPP_

#include "properties.hpp"

#endif
