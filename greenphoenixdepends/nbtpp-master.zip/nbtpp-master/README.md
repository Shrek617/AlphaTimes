# nbtpp

C++ library to parse minecraft's NBT format - https://wiki.vg/NBT
