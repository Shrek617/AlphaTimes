#include "tag.hpp"
#include "stde/streams/data.hpp"

using namespace nbtpp;
using namespace stde;
